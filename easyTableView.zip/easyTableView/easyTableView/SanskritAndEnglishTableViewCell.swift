//
//  SanskritAndEnglishTableViewCell.swift
//  easyTableView
//
//  Created by Jennifer Hott-Leitsch on 3/12/17.
//  Copyright © 2017 Jennifer Hott-Leitsch. All rights reserved.
//

import UIKit

class SanskritAndEnglishCell: UITableViewCell {
    var sanskrit: String = "" {
        didSet {
            if (sanskrit != oldValue){
                sanskritLabel.text = sanskrit}
        }}
    
    var english: String = "" {
        didSet{
            if (english != oldValue){
                englishLabel.text = english}
        }}
    var sanskritLabel: UILabel!
    var englishLabel: UILabel!
    
    override init(style: UITableViewCellStyle, reuseIdentifier: String?){
            super.init(style: style, reuseIdentifier: reuseIdentifier)
            let sanskritLabelRect = CGRect(x: 0, y: 5, width: 70, height: 15)
            let sanskritMarker = UILabel(frame: sanskritLabelRect)
            sanskritMarker.textAlignment = NSTextAlignment.right
            sanskritMarker.text = "Sanskrit:"
            sanskritMarker.font = UIFont.boldSystemFont(ofSize: 12)
            contentView.addSubview(sanskritMarker)
        
        
            let englishLabelRect = CGRect(x: 0, y: 26, width: 70, height: 15)
            let englishMarker = UILabel(frame: englishLabelRect)
            englishMarker.textAlignment = NSTextAlignment.right
            englishMarker.text = "English:"
            englishMarker.font = UIFont.boldSystemFont(ofSize: 12)
            contentView.addSubview(englishMarker)

            let sanskritValueRect = CGRect(x: 80, y: 5, width: 200, height: 15)
            sanskritLabel = UILabel(frame: sanskritValueRect)
            contentView.addSubview(sanskritLabel)

            let englishValueRect = CGRect(x: 80, y: 25, width: 200, height: 15)
            englishLabel = UILabel(frame: englishValueRect)
            contentView.addSubview(englishLabel)
            }

            required init?(coder aDecoder: NSCoder) {
                fatalError("init(coder:) has not been implemented")
            }

    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
