//
//  ViewController.swift
//  easyTableView
//
//  Created by Jennifer Hott-Leitsch on 3/12/17.
//  Copyright © 2017 Jennifer Hott-Leitsch. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITableViewDataSource {
    let cellTableIdentifier = "CellTableIdentifier"
    @IBOutlet var tableView:UITableView!
    let poses = [
        ["Sanskrit" : "Balasana", "English" : "Child Pose"],
        ["Sanskrit" : "Trikonasana", "English" : "Triangle Pose"],
        ["Sanskrit" : "Virabhadrasana", "English" : "Warrior Pose"],
        ["Sanskrit" : "Vrksansana", "English" : "Tree Pose"],
        ["Sanskrit" : "Utkatasana", "English" : "Fierce Pose"],
        ["Sanskrit" : "Parsvottanasana", "English" : "Flank Pose"],
        ["Sanskrit" : "Dandasana", "English" : "Staff Pose"],
        ["Sanskrit" : "Supta Hasta Padaghustasana", "English" : "Reclined Hand to Big Toe Pose"],
        ["Sanskrit" : "Jathara Parivartanasana ", "English" : "Revolved Belly Pose"],
        ["Sanskrit" : "Savasana", "English" : "Corpse Pose"]
    ]

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        tableView.register(SanskritAndEnglishCell.self,
                           forCellReuseIdentifier: cellTableIdentifier)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    //MARK:-
    //MARK:- Table View Data Source Methods
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return poses.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: cellTableIdentifier, for: indexPath)
            as! SanskritAndEnglishCell
        let rowData = poses[indexPath.row]
        cell.sanskrit = rowData["Sanskrit"]!
        cell.english = rowData["English"]!
        
        return cell
    }
    
    //Popup Alert
    /*func tableView(_tableView: UITableView, didSelectRowAt indexPath: IndexPath){
        let rowValue = poses[indexPath.row]
        let message = "You selected \(rowValue)"
        
        let controller = UIAlertController(title: "Row Selected",
                                           message: message, preferredStyle: .alert)
        let action = UIAlertAction(title: "Yes I did!",
                                   style: .default, handler: nil)
        controller.addAction(action)
        present(controller, animated: true, completion: nil)
    }*/
}

